package com;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Arrays;
import java.util.Objects;
import java.util.zip.*;

public class Test {
    public static void main(String[] args) throws IOException {
//        File f = new File(".");
        /*System.out.println(
                "separator:" + File.separator +
                        " Path:" + f.getPath() +
                        " AbsolutePath:" + f.getAbsolutePath() +
                        " CanonicalPath:" + f.getCanonicalPath() +
                        " canExecute:" + f.canExecute() +
                        " 可读:" + f.canRead() +
                        " 可写:" + f.canWrite()
        );*/
        Path p1 = Paths.get("."); // 构造一个Path对象
//        System.out.println(p1);
        Path p2 = p1.toAbsolutePath(); // 转换为绝对路径
//        System.out.println(p2);
        Path p3 = p2.normalize(); // 转换为规范路径
//        System.out.println(p3);
        File f = p3.toFile(); // 转换为File对象
//        fileList(f, 0);
//        System.out.println(copyFile("test.png", "test1.png"));
        try (ZipInputStream zip = new ZipInputStream(new FileInputStream("test.zip"))) {
            ZipEntry entry = null;
            while ((entry = zip.getNextEntry()) != null) {
                String name = entry.getName();
                System.out.println(name);
                if (!entry.isDirectory()) {
                    int n;
                    while ((n = zip.read()) != -1) {
                        System.out.println(n);
                    }
                }
            }
        }
    }

    public static String readAsString(InputStream input) throws IOException {
        int n;
        StringBuilder sb = new StringBuilder();
        while ((n = input.read()) != -1) {
            sb.append(n);
        }
        System.out.println(sb);
        return sb.toString();
    }

    private static boolean copyFile(String oldPath, String newPath) {
        File oldFile = new File(oldPath);
        File newFile = new File(newPath);
        try {
            if (oldFile.exists()) {
                try (InputStream input = new FileInputStream(oldFile)) {
                    try (OutputStream output = new FileOutputStream(newFile)) {
                        System.out.println(newFile.length());
                        byte[] buffer = new byte[1024];
                        int n = input.read(buffer);
                        int total = 0;
                        while (n != -1) {
                            total += n;
                            output.write(buffer, 0, n);
                            output.flush();
//                            模拟 写入中断 附加随机性
//                            if (total > oldFile.length() * Math.random()) {
//                                System.out.println(total);
//                                return false;
//                            }
                            n = input.read(buffer);

                        }
                        System.out.println((double) total + "B");
                        System.out.println((double) (total / 1024) + "kb");
                        return true;
                    }
                }
            } else {
                System.out.println("待复制的文件不存在");
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 列出指定目录下的所有子目录和文件，并按层次打印。
     */
    private static void fileList(File file, int level) {
        String separator = File.separator;
        String span = "-";
        if (file.isDirectory()) {
            System.out.println(span.repeat(level) + file.getName() + separator);
            for (File subFile : Objects.requireNonNull(file.listFiles())) {
                fileList(subFile, level + 1);
            }
        } else {
            System.out.println(span.repeat(level) + file.getName());
        }
    }
}
